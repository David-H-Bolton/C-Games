StarTrek.c
==========

Author D. Bolton. This was a conversion of the StarTrek.asc TinyBasic listing- in the TinyTrek.zip file. In my defence I was just startuing c programming and I did include the line numbers as comments in the c source code!
