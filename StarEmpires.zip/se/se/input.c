/* se */

#include <time.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h> /* needed for _getch() */
#include <math.h>
#include <Windows.h>


/* data structures  */
struct fleet {
	int from;
	int to;
	int turns;
	int fleetsize;
	int owner;
};

struct system {
	int x,y;
	int numfleets;
	int owner;
};

/* game data */
#define WIDTH 80
#define HEIGHT 50
#define MAXLEN 4

struct system galaxy[10];
struct fleet fleets[100];
char layout[5][5];
int numfleets;
int GameOver;
int Turn;
int cmdline=40;

/* returns a number between 1 and max */
int Random(int max) {
	return (rand() % max)+1;
}

int getsystem(int x,int y) {
	int i;
	for (i=0;i<10;i++)
		if (galaxy[i].x==x && galaxy[i].y==y){
			return i;
		}
	return -1; // should never get here!
}

char owner(int x,int y) {
	int i= getsystem(x,y);
	if (i != -1)
	  {
		if (galaxy[i].owner==0)
			return '+';
		else
			if (galaxy[i].owner==1)
			return '-';
			else
			return 'u';
		}
	return ' '; // should never get here!
}

void gotoxy( short x, short y ) 
{ 
    HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE) ; 
    COORD position = { x, y } ; 
     
    SetConsoleCursorPosition( hStdout, position ) ; 
}  

COORD GetConsoleSize() 
{ 
    HANDLE hnd = GetStdHandle(STD_OUTPUT_HANDLE) ; 
    return GetLargestConsoleWindowSize(hnd); 
}  

void ClrScr() {
	COORD c;
	DWORD NumWr;
	HANDLE hnd = GetStdHandle(STD_OUTPUT_HANDLE) ;
	c.X=0;
	c.Y=0;
     
    FillConsoleOutputCharacter(hnd,' ',WIDTH*HEIGHT,c,&NumWr);
	//FillConsoleOutputAttribute(hnd,0x88,4000,c,&NumWr);
}

COORD SetScreenSize(short x,short y) {
	COORD result; 
	HANDLE hnd;
	result.X=0;
	result.Y=0;
    hnd= GetStdHandle(STD_OUTPUT_HANDLE) ; 
    SetConsoleDisplayMode( hnd,CONSOLE_WINDOWED_MODE,&result);
    return result;
}

/* returns distance as character 1-6 */
char distance(int x,int y) {
   int distsqr= abs(x*x+y*y);
   int sqr = (int)sqrt((float)distsqr)+0.5;
   return (char)(sqr+48);
}

void InitSystem(int systemindex,int x,int y,int fleetcounts,int owner) {
		galaxy[systemindex].x=x;		
		galaxy[systemindex].y=y;
		galaxy[systemindex].numfleets = fleetcounts;
		galaxy[systemindex].owner = owner;
		layout[x][y]=(char)(systemindex+48);
}

void GenMapSystems() {
	int i,x,y;

	for (x=0;x<5;x++)
	for (y=0;y<5;y++) {
		layout[x][y]=' ';
	}

	InitSystem(0,0,0,50,0);
	InitSystem(9,4,4,50,1);

	/* Find an empty space for remaining 8 systems*/
	for (i=1;i<=8;i++) {
		do {
			x= Random(5)-1;
			y= Random(5)-1;
		}
		while (layout[x][y] !=' ');
	   InitSystem(i,x,y,15,-1);
	}
}

void DisplaySystems() {
int x,y;
gotoxy(0,5);printf("Map\n\r");
for (y=0;y<5;y++) {
	printf("   ");
	for (x=0;x<5;x++) {
		if (layout[x][y]==' ')
			printf(" .  ");
		else
			printf(" %c%c ",layout[x][y],owner(x,y));
	}
	
	printf("\n\r");
   }
}


void PrintDistances() {
int x,y,sx,sy,sx2,sy2;
gotoxy(0,12);printf("System Distances\n\r");
printf("        0  1  2  3  4  5  6  7  8  9\n\r");
printf("      -------------------------------\n\r");
for (y=0;y<10;y++) {
	printf("  %2d | ",y);
	sx = galaxy[y].x;
	sy = galaxy[y].y;
	for (x=0;x<10;x++) {
		if (x==y)
			printf("   ");
		else 
		{
			sx2 = galaxy[x].x;
			sy2 = galaxy[x].y;
			printf(" %c ",distance(sx-sx2,sy-sy2));
		 }
	}
	printf("| %2d\n\r",y);
   }
 printf("      -------------------------------\n\r");
 printf("        0  1  2  3  4  5  6  7  8  9\n\r");
}

void InitData() {
	for (numfleets=0;numfleets < MAXFLEETS;numfleets++)
		Fleets[i]
	numfleets=0;
	GameOver=0;
	srand((int)time(NULL));
	Turn=1;
}

void DisplayPlanets() {
	int i,owner;
	char text[20];
	gotoxy(45,13);printf("Planets(Owner) Ships");
	for (i=0;i<10;i++) {
	  gotoxy(45,14+i);
	  owner = galaxy[i].owner;
	  if (owner==-1 )
		strcpy(text,"None");
	  else
		  _snprintf(text,5,"%i",owner);
	  printf("%2i (%5s)    %3i",i,text,galaxy[i].numfleets);
	}
}

void clr(int line) {
	int i;
	gotoxy(0,line);
	for (i=0;i<WIDTH;i++)
	{
		printf(" ");
	}
}

void waitms(int numms) {
	clock_t until;
	until = clock()+numms;	// 1,2,3...		
	while (clock() < until) {
		if (_kbhit())
			break;
	}
}

void ShowTurn() {
	gotoxy(45,5);
	printf("Turn %d",Turn++);
}

int getkey() {

	clock_t until;
	until = clock()+numms;	// 1,2,3...		
	while (clock() < until) {
		if (_kbhit())
			break;
	}
}

/* handles input chars 0-9, backspace and return */
int GetInput() {
	char * back ="\b \b";
	char buffer[MAXLEN+1]; // max 4 digits
	char key;
	int result=0;
	int buflen=0;
	int hitreturn=0;
	buffer[0]='\0';
	do {
		key=_getch();
		if (key==27)
			return -1;
		buflen=strlen(buffer);
		if ((buflen < MAXLEN && key >='0' && key <='9') || 
			(buflen >0 && (key== 8 || key==13)))
		{
			  if (key ==13)
				  hitreturn=1;
			  else
				if (key==8)
				{
					buffer[--buflen]='\0';
					printf("%s",back);
					
				}
				else
				{
					buffer[buflen++]=key;
					buffer[buflen]='\0';				
					printf("%c",key);
				}
		}
	}
     while (!hitreturn);
  return atoi(buffer);
}

void AddFleet(int player,int numships,int source,int target) {


}

void Process_Command(char c) {
	char t;
	int source,target,numfleets;
	gotoxy(0,cmdline+1);printf("Target System: Press 0-9: ");
	t=_getch();
	printf("%c",t);
	if (t >='0' && t <='9' && t != c) {
		if (c=='a' || c=='A')
			source =99;
		else
			source = (int)(c-'0');
		target = (int)(t-'0');
		gotoxy(0,cmdline+2);printf("How Many fleets:");numfleets=GetInput();
		if (numfleets >-1)
		  {
			  gotoxy(0,cmdline+3);printf("Move %d from %d to %d",numfleets,source,target);
			  waitms(1000);
			  clr(cmdline+3);
			  AddFleet(0,numfleets,source,target);
		}
		clr(cmdline+1);
		clr(cmdline+2);
	}
	
}

void GetandProcessOrders() {
	clock_t onesec;
	char c;
	onesec = clock()+5000;	// Five second on...		
	gotoxy(0,cmdline);printf("Move Command: Press 0-9 or A(ll):");
	while (clock() < onesec) {

		if (_kbhit())  // Key pressed
		{
			c = _getch();
			if (c=='\0')
				c=_getch();
			if (c==27)	{
					GameOver=1;
					return;
			}
			printf("%c",c);
			if ((c>='0' && c <='9') || (c=='a' || c=='A')) {
				{
					
					Process_Command(c);
					gotoxy(0,cmdline);printf("Move Command: Press 0-9 or A(ll): ");
				}
			}
			else
			{
				printf("%c",7);
			}
		}

	}
}

int main(int argc, char * argv[])
{

};
